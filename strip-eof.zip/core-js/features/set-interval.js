var parent = require('../stable/set-interval');

module.exports = parent;
