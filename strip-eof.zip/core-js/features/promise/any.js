var parent = require('../../stable/promise/any');

// TODO: Remove from `core-js@4`
require('../../modules/esnext.aggregate-error');
require('../../modules/esnext.promise.any');

module.exports = parent;
