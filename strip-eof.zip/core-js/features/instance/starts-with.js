var parent = require('../../stable/instance/starts-with');

module.exports = parent;
