var parent = require('../../stable/instance/slice');

module.exports = parent;
