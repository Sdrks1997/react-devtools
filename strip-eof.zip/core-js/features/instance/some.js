var parent = require('../../stable/instance/some');

module.exports = parent;
