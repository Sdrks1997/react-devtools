var parent = require('../../stable/instance/filter');

module.exports = parent;
