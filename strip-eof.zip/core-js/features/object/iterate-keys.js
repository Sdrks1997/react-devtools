require('../../modules/esnext.object.iterate-keys');
var path = require('../../internals/path');

module.exports = path.Object.iterateKeys;
