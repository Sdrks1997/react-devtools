var parent = require('../../stable/object/define-setter');

module.exports = parent;
