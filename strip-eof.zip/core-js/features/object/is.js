var parent = require('../../stable/object/is');

module.exports = parent;
