var parent = require('../../stable/object/create');

module.exports = parent;
