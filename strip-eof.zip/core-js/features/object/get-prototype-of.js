var parent = require('../../stable/object/get-prototype-of');

module.exports = parent;
