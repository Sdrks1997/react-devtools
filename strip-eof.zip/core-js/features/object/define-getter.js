var parent = require('../../stable/object/define-getter');

module.exports = parent;
