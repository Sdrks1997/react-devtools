var parent = require('../../stable/array/copy-within');

module.exports = parent;
