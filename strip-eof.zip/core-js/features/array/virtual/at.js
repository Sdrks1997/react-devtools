require('../../../modules/esnext.array.at');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').at;
