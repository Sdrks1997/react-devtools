var parent = require('../../../stable/array/virtual/reduce-right');

module.exports = parent;
