var parent = require('../../../stable/array/virtual');
require('../../../modules/es.map');
require('../../../modules/esnext.array.at');
// TODO: Remove from `core-js@4`
require('../../../modules/esnext.array.filter-out');
require('../../../modules/esnext.array.filter-reject');
require('../../../modules/esnext.array.find-last');
require('../../../modules/esnext.array.find-last-index');
require('../../../modules/esnext.array.group-by');
require('../../../modules/esnext.array.unique-by');

module.exports = parent;
