var parent = require('../../../stable/array/virtual/map');

module.exports = parent;
