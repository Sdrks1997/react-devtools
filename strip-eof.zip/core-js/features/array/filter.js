var parent = require('../../stable/array/filter');

module.exports = parent;
