require('../../modules/esnext.array.at');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'at');
