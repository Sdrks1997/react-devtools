var parent = require('../../stable/array/of');

module.exports = parent;
