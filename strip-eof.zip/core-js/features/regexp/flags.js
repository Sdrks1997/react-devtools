var parent = require('../../stable/regexp/flags');

module.exports = parent;
