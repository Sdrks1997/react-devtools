require('../../modules/esnext.reflect.delete-metadata');
var path = require('../../internals/path');

module.exports = path.Reflect.deleteMetadata;
