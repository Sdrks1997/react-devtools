var parent = require('../../stable/json/to-string-tag');

module.exports = parent;
