var parent = require('../stable/get-iterator');

module.exports = parent;
