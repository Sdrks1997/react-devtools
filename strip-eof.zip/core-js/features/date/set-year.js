var parent = require('../../stable/date/set-year');

module.exports = parent;
