var parent = require('../../stable/date/to-primitive');

module.exports = parent;
