var parent = require('../../../stable/number/virtual/to-precision');

module.exports = parent;
