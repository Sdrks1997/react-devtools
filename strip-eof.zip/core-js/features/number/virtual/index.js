var parent = require('../../../stable/number/virtual');

module.exports = parent;
