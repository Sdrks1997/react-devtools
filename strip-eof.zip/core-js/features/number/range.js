require('../../modules/es.object.to-string');
require('../../modules/esnext.number.range');
var path = require('../../internals/path');

module.exports = path.Number.range;
