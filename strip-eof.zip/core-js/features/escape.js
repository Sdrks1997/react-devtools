var parent = require('../stable/escape');

module.exports = parent;
