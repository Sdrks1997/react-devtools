var parent = require('../../stable/math/expm1');

module.exports = parent;
