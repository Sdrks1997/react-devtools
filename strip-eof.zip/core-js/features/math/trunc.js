var parent = require('../../stable/math/trunc');

module.exports = parent;
