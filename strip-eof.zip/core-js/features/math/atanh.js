var parent = require('../../stable/math/atanh');

module.exports = parent;
