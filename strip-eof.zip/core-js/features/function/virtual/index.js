var parent = require('../../../stable/function/virtual');

module.exports = parent;
